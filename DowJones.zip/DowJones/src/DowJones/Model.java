package DowJones;

public class Model {

}
